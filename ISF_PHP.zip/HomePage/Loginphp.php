
   
<?php
include("ISF_queryClass.php");

function loginCheck($string1,$string2){
	$username = $string1;
	$password = $string2;
	$dbclass = new DatabaseClass;
	$sql = "SELECT FirstName,LastName FROM students_table WHERE UserName = '$username' AND 	Password = '$password' ;" ;
	try{
			 $result = $dbclass->dbquery($sql);
			 
			 $row = $result->fetch_assoc();
			 
                 if(!empty($row)){	// if we get more than 1 row with same user and password ,because username and password are not unique in our table.(unique key is email)		 
			         
                     $_SESSION['firstname'] = $row['FirstName'];
                      $_SESSION['lastname'] = $row['LastName'];	 
			          return true;
				    }else{
						/*print_r("hi".$row['FirstName'].$row['LastName']);*/
						return false;}
			 
		 }catch(Exception $e){
			 echo '<script>window.alert("You are not registered with ISF please register and Then login !!")</script>';
		 }
}

?>