<!--
Created by Chaitanya Prashanth A v , 700656889
Created By Olawunmi Shyllon , 700647413.

-->
<?php session_start();?>

<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content = "width=device-width">
	<title>ISF.org</title>
	<link rel="stylesheet" type="text/css" href="RealuserServices.css"/>
	<script type="text/javascript" src="register.js"></script>
	</head>

<body>
    <div class="userserviceheader">
			<div class="userlogos">
			<a href="Home.php"><img src="./Images/logo-main.png"></a>
			<nav>
				<ul>
					<li><a href="Userhome.php">Home</a></li>
					<li><a href="RealUser.php">Resources</a></li>
					<li><a href="RealuserServices.php">Services</a></li>
					<li><a href="RealuserAboutUs.php">About Us</a></li>
					<li><a href="Userlogout.php">Log Out</a></li>
				</ul>
			    </nav>
			</div>
	</div>
			
	<div id ="userintro">
	<img src="images/text11.jpg" id="block1">
	<img src="images/text10.jpg" id="block2">

	
	</div>

	
	<div id="userbookphone">
    <div>
        <img src="./Images/book1.jpg" class ="book" />
        <p><a href="http://www.chegg.com/books">buy or rent books at Cheggs</p>
    </div>
    <div>
        <img src="./Images/cars1.jpg" class ="mycar" />
        <p>rent a car at <a href="https://www.hertz.com/rentacar/reservation/">Hertz</p>
    </div>
    <div>
        <img src="./Images/phone1.jpg" class ="phone" />
        <p><a href="http://www.whistleout.com/CellPhones">Compare phone plans</p>
    </div>

</div>

<div id="userhomeshop">
    <div>
        <img src="./Images/home2.jpg" class ="myhome" />
        <p>find a home at<a href="https://www.zillow.com/homes/for_rent/">Zillows</p>
    </div>
    <div>
        <img src="./Images/license1.jpg" class ="myid" />
        <p>Obtain License<a href="http://www.dmv.org/drivers-license.php">Info</p>
    </div>
    <div>
        <img src="./Images/cart1.jpg" class ="shop"/>
        <p><a href="https://www.amazon.com/dp/B00DBYBNEE?_encoding=UTF8&ref_=nav_swm_AS_GW_swm_grphc3"> Amazon Prime Student</p>
    </div>

</div>
	
	
	
	             	
		<footer>
           
             <table id = "footer-content">
			  <tr> <td> <img id = "footer-logo" src ="./Images/logo-footer.png" width = "80" height ="80" alt="ISP logo"></td>
			       <td id = "footer-text" style = "padding-left : 3%;">
			         <h6>About International Student page</h6>
			         <p>"..Our vision is to be the company that best recognizes and serves
       		             the needs of international students around the world.We strive to
			             provide students world-class resources to help them investigate and
			             pursue an international education, through relevant content, custom 
                         online tools and engaging websites that offer only best in class products and services."
			         </p>
				    </td>
				    <td id= "socialpic">
					      <p> <strong> To connect with us click on the below social media links</strong></p>
				          <p id="links" style = "padding-left : 225px">
						  <a href="https://www.facebook.com/" target ="New Window"> <img src="./Images./SocialMedia/Facebook.png" height="50" width="50" alt="Facebook" id="face"> </a>
						  <a href="https://plus.google.com/" target ="New Window"> <img src="./Images./SocialMedia/GooglePlus.png" height="50" width="50" alt="GooglePlus" id="google"> </a>
						  <a href="https://www.linkedin.com/uas/login" target ="New Window"> <img src="./Images./SocialMedia/Linkedin.png" height="50" width="50" alt="Linkedin" id="link"> </a>
						  <a href="https://twitter.com/" target ="New Window"> <img src="./Images./SocialMedia/twitter.png" height="50" width="50" alt="twitter" id="twit"> </a>
						  <a href="https://www.youtube.com/" target ="New Window"> <img src="./Images./SocialMedia/youtube.png" height="50" width="50" alt="youtube" id="tube"> </a>
						  </p>
					      
					</td> 
				</tr>
		     </table> 
		   
   </footer>

</body>
</html>