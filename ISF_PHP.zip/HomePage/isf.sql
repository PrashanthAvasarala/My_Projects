-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Apr 24, 2017 at 06:38 AM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 5.5.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `isf`
--
CREATE DATABASE IF NOT EXISTS `isf` DEFAULT CHARACTER SET utf8 COLLATE utf8_unicode_ci;
USE `isf`;

-- --------------------------------------------------------

--
-- Table structure for table `students_table`
--

CREATE TABLE `students_table` (
  `FirstName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `LastName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `University` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `Status` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `UserName` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Password` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `Email` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `Mobile` varchar(12) COLLATE utf8_unicode_ci NOT NULL,
  `OriginCountry` varchar(20) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `students_table`
--

INSERT INTO `students_table` (`FirstName`, `LastName`, `University`, `Status`, `UserName`, `Password`, `Email`, `Mobile`, `OriginCountry`) VALUES
('Anusha', 'Venky', 'Eastern Illionis University', 'Enrolled', 'nush12', 'venush35', 'anusha@yahoomail.com', '8163725650', 'Australia'),
('Yande', 'Bastur', 'University of Central Missouri', 'Enrolled', 'yand2', 'yanga2', 'bastur@yahoo.com', '9132247863', 'Canada'),
('Kelli', 'Belch', 'Minnesota State Univ Mankanto', 'Enrolled', 'kebech04', 'bechaer09', 'belch@yahoo.com', '8162447588', 'Australia'),
('Sandra', 'Briggs', 'Eastern Illionis University', 'Alumni', 'briggs', 'brigado17', 'brigsand@gmail.com', '9132664545', 'Canada'),
('Mary', 'Bush', 'Minnesota State Univ Mankanto', 'Alumni', 'mabush', 'mabush17', 'bushma@gmail.com', '9132554499', 'India'),
('Gloria', 'Bechtid', 'Minnesota State Univ Mankanto', 'Current Student', 'bechas04', 'chasut14', 'chasm@yahoo.com', '8165542255', 'Australia'),
('Brenda', 'Cole', 'University of Central Missouri ', 'Alumni', 'brend12', 'cole20', 'cole@outlook.com', '8132554687', 'Canada'),
('Chaitanya Prashanth', 'Avasarala', 'University of Central Missouri', 'Current Student', 'Chaitanya786', 'Chaithu786', 'cxa68890@ucmo.edu', '8163725650', 'India'),
('Yasmin', 'Yadava', 'Eastern Illionis University', 'Current Student', 'yasda01', 'gutha20', 'damin27@gmail.com', '8162447551', 'Canada'),
('Daphne', 'Yasmin', 'University of Central Missouri', 'Alumni', 'dapt34', 'yasmin32', 'dapyas@gmail.com', '9134257889', 'India'),
('Nithin', 'Malaguma', 'Eastern Illionis University', 'Current Student', 'masdam12', 'dafrun10', 'dasmath76@yahoo.com', '9134478822', 'Australia'),
('Donald', 'Clinton', 'Minnesota State Univ Mankanto', 'Enrolled', 'dolton12', 'donatus05', 'donaldino@gmail.com', '9132554478', 'Canada'),
('Finish', 'Grill', 'Eastern Illionis University', 'Current Student', 'varxh', 'varila02', 'drill@yahoo.com', '8162551474', 'Australia'),
('Precious', 'Fountain', 'Eastern Illionis University', 'Alumni', 'fount', 'fount14', 'fontana@gmail.com', '8162223358', 'Australia'),
('Tiffany', 'Gamble', 'Eastern Illionis University', 'Enrolled', 'tiffs', 'gammy12', 'gammy@gmail.com', '9132446589', 'Canada'),
('Rathor', 'Balagav', 'Eastern Illionis University', 'Current Student', 'balagav01', 'rat10', 'gerner@gmail.com', '8162554265', 'India'),
('Harold', 'Green', 'University of Central Missouri', 'Enrolled', 'hard2', 'green6', 'harold@gmail.com', '9134879622', 'Canada'),
('Sai', 'Kamal', 'Eastern Illionis University', 'Current Student', 'kamal14', 'saikam12', 'kamal@gmail.com', '813225449', 'India'),
('Yadav', 'manish', 'Eastern Illionis University', 'Enrolled', 'manty6', 'manato13', 'manita@yahoo.com', '9132558866', 'Australia'),
('Michael', 'Stephens', 'Minnesota State Univ Mankanto', 'Alumni', 'mike14', 'mikalo08', 'mikkaka@outlook.com', '8164552277', 'Canada'),
('Monica', 'Lester', 'Minnesota State Univ Mankanto', 'Current Student', 'monta21', 'nutrew13', 'monalid@gmail.com', '8162447758', 'Canada'),
('Desmond', 'Elliot', 'Minnesota State Univ Mankanto', 'Alumni', 'desma', 'desamp16', 'mondi@gmail.com', '8167774422', 'Australia'),
('Venu', 'Naga', 'Eastern Illionis University', 'Alumni', 'mona21', 'nagy54', 'nagave@outlook.com', '9136457725', 'Australia'),
('Nikitha', 'Anusha', 'Eastern Illionis University', 'Alumni', 'niki75', 'hunda12', 'nikisha@gmail.com', '8134775522', 'Canada'),
('Ronald', 'Harley', 'Minnesota State Univ Mankanto', 'Enrolled', 'ron15', 'harnet12', 'nnhero@gmail.com', '8162254477', 'India'),
('Benji', 'Palagutha', 'Eastern Illionis University', 'Alumni', 'benj12', 'gutha34', 'palagu@yahoo.com', '9132654774', 'India'),
('Venush', 'Panira', 'Eastern Illionis University', 'Alumni', 'pamai10', 'pamato91', 'panira@gmail.com', '8165774122', 'India'),
('Peter', 'Paul', 'University of Central Missouri ', 'Enrolled', 'pete', 'pete20', 'pete23@gmail.com', '9132223476', 'India'),
('Harsha', 'Reddy', 'Eastern Illionis University', 'Enrolled', 'harsh21', 'redhar16', 'redhar13@gmail.com', '9132547788', 'Canada'),
('Santosh', 'Kumar', 'Eastern Illionis University', 'Enrolled', 'kumar25', 'kumar23', 'santosh@gmail.com', '8162547899', 'India'),
('Bastien', 'Shawana', 'University of Central Missouri ', 'Current Student', 'baster10', 'shawy20', 'shawy@yahoo.com', '8162558952', 'Canada'),
('Ramen', 'Ramesh', 'Eastern Illionis University', 'Current Student', 'terun', 'trueb74', 'tarun@outlook.com', '8164772564', 'Canada'),
('Tito', 'Johnson', 'University of Central Missouri', 'Current Student', 'titan21', 'john24', 'titojon@outlook.com', '9132552468', 'Australia'),
('Venkata', 'Reddy', 'Eastern Illionis University', 'Enrolled', 'venk10', 'venkyred02', 'venkata@gmail.com', '8162554878', 'India'),
('Victor', 'Williams', 'Minnesota State Univ Mankanto', 'Current Student', 'vick23', 'willi24', 'vistar@yahoo.com', '9132556699', 'India'),
('Daniel', 'Waters', 'University of Central Missouri ', 'Alumni', 'dan10', 'dan1010', 'waters@yahoo.com', '8162554687', 'Canada'),
('Yemisi', 'Browne', 'University of Central Missouri', 'Current Student', 'yeni65', 'bram23', 'yemibrowne@gmail.com', '8162554632', 'Canada');

-- --------------------------------------------------------

--
-- Table structure for table `university_table`
--

CREATE TABLE `university_table` (
  `UniversityName` varchar(60) COLLATE utf8_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `university_table`
--

INSERT INTO `university_table` (`UniversityName`) VALUES
('Arizona State University'),
('Eastern Illionis University'),
('McNeese State University'),
('Minnesota State Univ Mankanto'),
('Pennsylvania State University'),
('Texas A&M University'),
('University of Central Missouri'),
('University of Minnesota'),
('University of Pennsylvania'),
('University of Southern California');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students_table`
--
ALTER TABLE `students_table`
  ADD PRIMARY KEY (`Email`);

--
-- Indexes for table `university_table`
--
ALTER TABLE `university_table`
  ADD PRIMARY KEY (`UniversityName`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
