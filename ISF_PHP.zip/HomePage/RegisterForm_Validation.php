<?php

function validatename($string){
	   return preg_match('/^.*[a-zA-Z]$/',trim($string)); 
  }
function dropdown(){ /* we can use this dropdown function or other dropdown function in RealUserfun.php (Method Overriding */
	 
	  $string = selectUniversity();
	  $i=0;
	  $UniversityName = array();
			while($row = $string->fetch_assoc()){
				$UniversityName[$i] = $row['UniversityName'];
				$i++;
			}
	   if(in_array($_POST['University'] , $UniversityName)){
		   return true;
          }
		else{
			return false;
		}
  }
  
 
  
function datalist($string){
	return (empty($string)? false : true ) ;	
}  

function crendential($string){
	  
	  return preg_match('/^.*[a-zA-Z0-9]$/',trim($string)); 
	 
}
 
function password($string){
	  
	  if(!empty($string)){
	  return preg_match('/^.*([a-zA-Z0-9]{6,10})$/' ,trim($string));}
	  
	  
}

function email($string){
	
	$result = selectEmail();
	$emailid = array();
	$i=0;
	while($row = $result->fetch_assoc()){
		$emailid[$i] = $row['Email'];
		$i++;
	}
	
	if(empty($string)){
	      return true ; 
	}else{
	     foreach($emailid as $email){
			if(!strcmp($email,$string)){ // strcmp returns value 0 if $email = $string exists in isf database 
			return true; }
		 }
	}
	
	return false;
}

function mobile($string){
	if(empty($string)){
	      return false ; 
	}else{
	    return preg_match('/^.*([0-9]{10})$/' ,trim($string));
	}
	
}

?>