<?php session_start();?>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content = "width=device-width">
	<title>ISF.org</title>
	<link rel="stylesheet" type="text/css" href="Realuseraboutus .css"/>
	 
			<style type = "text/css">
			td{text-align:Center;
               font-weight:bold;}
			table{
			 border-spacing: 10px;
			}
			</style>
</head>

<body style = "background-image : url('./Images./Slides/slide3.jpg');">

    <div class = "slides">
		<div class="logo"> <!-- how to link image to home.html-->
			<a href="Userhome.php"><img src="./Images/logo-main.png"></a>
			<nav>
				<ul>
					<li><a href="Userhome.php">Home</a></li>
					<li><a href="RealUser.php">Resources</a></li>
					<li><a href="RealuserServices.php">Services</a></li>
					<li><a href="RealuserAboutUs.php">About Us</a></li>
					<li><a href="Userlogout.php">Log Out</a></li>
					
				</ul>
			    </nav>
			</div> 
		
<div style= "margin-Top:100px;margin-left:80px">
<table >
<tr>
<td> Name </td>
<td> Student Id </td>
<td> Contact Number </td>
<td> Email </td>
<td> Course Enrolled </td>
<td> Department </td>
<td> University </td>
</tr>
<tr>
<td> Vishnuvardhan Reddy Sheelam </td>
<td> 700654268 </td>
<td> 816-299-3569 </td>
<td> vxs42680@ucmo.edu </td>
<td> Internet for the Enterprise </td>
<td> Computer Information Systems </td>
<td> University of Central Missouri </td>
</tr>
<tr>
<td> Chaitanya Prashanth Avasarala </td>
<td> 700656889 </td>
<td> 816-372-5650 </td>
<td> CXA68890@ucmo.edu </td>
<td> Internet for the Enterprise </td>
<td> Computer Information Systems </td>
<td> University of Central Missouri </td>
</tr>
</tr>
<tr>
<td> Olawunmi Shyllon </td>
<td> 700647413 </td>
<td> 913-292-9914 </td>
<td> Ola@ucmo.edu </td>
<td> Internet for the Enterprise </td>
<td> Computer Information Systems </td>
<td> University of Central Missouri </td>
</tr>
<tr>
<td> HTML5: An Introduction </td>
<td> CIS5610</td>
<td> Spring 2017</td>
<td> CSS Demystified </td>
<td> Internet for the Enterprise </td>
<td> Computer Information Systems </td>
<td> University of Central Missouri </td>
</tr>
</table>
 </div>     
</div>

   <footer style = "margin : 400px -5px 0px 0px;"><!--Margin (top right bottom left)-->
           
             <table id = "footer-content">
			  <tr> <td> <img id = "footer-logo" src ="./Images/logo-footer.png" width = "80" height ="80" alt="ISP logo"></td>
			       <td id = "footer-text" style = "padding-left : 3%;">
			         <h6>About International Student page</h6>
			         <p>"..Our vision is to be the company that best recognizes and serves
       		             the needs of international students around the world.We strive to
			             provide students world-class resources to help them investigate and
			             pursue an international education, through relevant content, custom 
                         online tools and engaging websites that offer only best in class products and services."
			         </p>
				    </td>
				    <td id= "socialpic">
					      <p> <strong> To connect with us click on the below social media links</strong></p>
				          <p id="links" style = "padding-left : 225px">
						  <a href="https://www.facebook.com/" target ="New Window"> <img src="./Images./SocialMedia/Facebook.png" height="50" width="50" alt="Facebook" id="face"> </a>
						  <a href="https://plus.google.com/" target ="New Window"> <img src="./Images./SocialMedia/GooglePlus.png" height="50" width="50" alt="GooglePlus" id="google"> </a>
						  <a href="https://www.linkedin.com/uas/login" target ="New Window"> <img src="./Images./SocialMedia/Linkedin.png" height="50" width="50" alt="Linkedin" id="link"> </a>
						  <a href="https://twitter.com/" target ="New Window"> <img src="./Images./SocialMedia/twitter.png" height="50" width="50" alt="twitter" id="twit"> </a>
						  <a href="https://www.youtube.com/" target ="New Window"> <img src="./Images./SocialMedia/youtube.png" height="50" width="50" alt="youtube" id="tube"> </a>
						  </p>
					      
					</td> 
				</tr>
		     </table> 
		   
   </footer>
   
     
   
</body>
</html>