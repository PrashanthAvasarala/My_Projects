<!DOCTYPE html>
<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content = "width=device-width">
	<title>ISF.org</title>
	<link rel="stylesheet" type="text/css" href="Register.css"/>
	
	<?php include('Insert_StudentDetails.php');?>
</head>

<body>
    <div class="formheader">
			<div class="logo"> <!-- how to link image to home.html-->
			<a href="Home.php"><img src="./Images/logo-main.png"></a>
			<nav>
				<ul>
					<li><a href="Home.php">Home</a></li>
					<li><a href="Resources.php">Resources</a></li>
					<li><a href="Resources.php">Services</a></li>
					<li><a href="Register.php">Register</a></li>
					<li><a href="Resources.php">About Us</a></li>
				</ul>
			    </nav>
			</div>
	
	
	
	        <div id="inter">
			<h2 id = "text" style = "color : #cc0000 ; margin-left : 250px;">Students with admits from  Universities can  Register here </h2>
			
			</div>
			
			<div class = "regisform" >
					
			<form class="regix" method="post" action="Register.php" >
			
			<p><label style = "margin-left : -100px;">First Name:</label> <input type="text" name="firstName" value = "<?php if(isset($_POST['submit'])) {echo $_POST['firstName'];}?> " style = "margin-left : 70px;" /></p>
			<p><label style = "margin-left : -100px;">Last Name: </label> <input type="text" name="lastName" value = "<?php if(isset($_POST['submit'])) {echo $_POST['lastName'];}?> " style = "margin-left : 75px;"/></p>
			<p><label style = "margin-left : -100px;">University: </label> <input type="text" name="University" placeholder = "Admitted University" list ="University"  style = "margin-left : 78px;"/></p>
			<datalist id = "University" > 
			<?php 
			$result = selectUniversity();
			while($row = $result->fetch_assoc()){
				$UniversityName = $row['UniversityName'];
				echo "<option value = '".$UniversityName."'</option>";
			}
			 ?> </datalist></p> 
			<p><label style = "margin-left : -100px;">Status : </label><input type="text" name="Status" value = "<?php if(isset($_POST['submit'])) { echo $_POST['Status'];}?>" list = "Status" style = "margin-left : 100px;"/></p>
			<datalist id="Status">
							 <option value = "Enrolled">
							 <option value = "Current Student">
							 <option value = "Alumni">
							 </datalist></p> 
			<p><label style = "margin-left : -100px;">User Name: </label><input type="text" name="userName" id="myUser" placeholder = "username" value = "<?php if(isset($_POST['submit'])) {echo $_POST['userName'];}?>"style = "margin-left : 72.5px;"/></p>
			<p><label style = "margin-left : -100px;">Password:</label> <input type="password" name="password" placeholder = "*******" value = "<?php if(isset($_POST['submit'])) {echo $_POST['password'];}?>" style = "margin-left : 82px;"/></p>
			<p><label style = "margin-left : -100px;"> Confirm Password:</label> <input type="password" name="confirmpassword" placeholder = "*******" value = "<?php if(isset($_POST['submit'])) {echo $_POST['confirmpassword'];}?>" style = "margin-left : 20px;"/></p>
			<p><label style = "margin-left : -100px;">Email: </label><input type="email" name="email" placeholder = "example@hotmail.com" value = "<?php if(isset($_POST['submit'])) {echo $_POST['email'];}?>" style = "margin-left : 108px;"/></p>
			<p><label style = "margin-left : -100px;">Mobile: </label><input type="text" name="mobile" value = "<?php if(isset($_POST['submit'])) {echo $_POST['mobile'];}?>" style = "margin-left : 102px;"/></p>
			<p><label style = "margin-left : -100px;" >Origin Country:</label>
			<input type = "text" name = "Country" placeholder = "Country Name"  list = "Country"  value = "<?php if(isset($_POST['submit'])) {echo $_POST['Country'];}?>" style = "text-align : center ; margin-left : 45px;"/>
			<datalist id="Country">
							 <option value = "Canada">
							 <option value = "India">
							 <option value = "Mexico">
							 <option value = "Australia">
							 <option value = "China">
							 <option value = "Indonesia">
							 <option value = "Malaysia">
							 <option value = "Italy">
							 <option value = "Cambodia">
							 <option value = "Austria">
							 </datalist></p> 
			<p>
			<input type="submit" name="submit" value="Submit" style = "background-color:  #ff6600; font-weight: bold;"/>
			<input type="reset" name="reset" value="Reset" onclick = "window.location.href = 'Register.php'" style = "background-color:  #ff6600; font-weight: bold;"/>
			<br><br><br><br></p>
					
			</form>
			</div>
			

			<?php
			if(isset($_POST['submit'])){
				include("RegisterForm_Validation.php");
				if(validatename($_POST['firstName'])){
					  if(validatename($_POST['lastName'])){
					         if(dropdown()){ /* In Datalist User can select or write the university name if student writes other university names not in the list it should not accept , that is the reason we use dropdown function to compare university */
								 if(datalist($_POST['Status'])){
									  if(crendential($_POST['userName'])){
										  if(password($_POST['password'])){
											  if(!strcmp($_POST['password'],$_POST['confirmpassword'])){
												         if(!email($_POST['email'])){
															 if(mobile($_POST['mobile'])){
																  if(datalist($_POST['Country'])){
															             insertStudentDetail();
																  }else{
																  echo '<script>document.getElementById("text").innerHTML = "Country is not selected" ;</script>';}
															  }else{
																  	echo '<script>document.getElementById("text").innerHTML = "Either mobile number Field is empty /<br> entered more than 10 digits please exclude country code " ; </script>';}													  
												         }else{
													       echo '<script>document.getElementById("text").innerHTML = "Either Email Field is empty /<br> This email ID is already registered with ISF " ; </script>';}
										         }else{
										          echo '<script>document.getElementById("text").innerHTML = "Password and confirm password does not match" ; </script>';}
										  }else{
											 echo '<script>document.getElementById("text").innerHTML = "Password field should not be empty /<br> it should contain 6-10 alphnum characters with no symbols in it" ; </script>';}
									 }else{
									   echo '<script>document.getElementById("text").innerHTML = "UserName is not Valid and it should <br>contain alpha numeric without symbols" ; </script>';}
								 }else{
								 echo '<script> document.getElementById("text").innerHTML = "Please select your Student status" ;</script>';}
							 }else{
							   echo '<script> document.getElementById("text").innerHTML = "Please select your university name " ;</script>';}
				      }else{
						echo '<script> document.getElementById("text").innerHTML = "Last name should not contain blank/spaces/any <br>special characters!!" ;</script>';}
				}else{
					echo '<script> document.getElementById("text").innerHTML = "First name should not contain blank/spaces/any <br>special characters!! " ;</script>';}
			}	
			 
	         ?>
		
		<div class="benefits">
		    	
		<img src="images/benefit.jpg" class="beft">
					
		</div>
			     
		<div class="testimonials">
		    	
		<img src="images/students1.jpg" class="image1">
		<img src="images/students2.jpg" class="image2">
		<img src="images/students3.jpg" class="image3">
		<img src="images/students4.jpg" class="image4">
		</div>			 
	</div>	 						 
                 	
		<footer style = "margin-top : 1300px;">
           
             <table id = "footer-content">
			  <tr> <td> <img id = "footer-logo" src ="./Images/logo-footer.png" width = "80" height ="80" alt="ISP logo"></td>
			       <td id = "footer-text" style = "padding-left : 3%;">
			         <h6>About International Student page</h6>
			         <p>"..Our vision is to be the company that best recognizes and serves
       		             the needs of international students around the world.We strive to
			             provide students world-class resources to help them investigate and
			             pursue an international education, through relevant content, custom 
                         online tools and engaging websites that offer only best in class products and services."
			         </p>
				    </td>
				    <td id= "socialpic">
					      <p> <strong> To connect with us click on the below social media links</strong></p>
				          <p id="links" style = "padding-left : 225px">
						  <a href="https://www.facebook.com/" target ="New Window"> <img src="./Images./SocialMedia/Facebook.png" height="50" width="50" alt="Facebook" id="face"> </a>
						  <a href="https://plus.google.com/" target ="New Window"> <img src="./Images./SocialMedia/GooglePlus.png" height="50" width="50" alt="GooglePlus" id="google"> </a>
						  <a href="https://www.linkedin.com/uas/login" target ="New Window"> <img src="./Images./SocialMedia/Linkedin.png" height="50" width="50" alt="Linkedin" id="link"> </a>
						  <a href="https://twitter.com/" target ="New Window"> <img src="./Images./SocialMedia/twitter.png" height="50" width="50" alt="twitter" id="twit"> </a>
						  <a href="https://www.youtube.com/" target ="New Window"> <img src="./Images./SocialMedia/youtube.png" height="50" width="50" alt="youtube" id="tube"> </a>
						  </p>
					      
					</td> 
				</tr>
		     </table> 
		   
   </footer>

</body>
</html>