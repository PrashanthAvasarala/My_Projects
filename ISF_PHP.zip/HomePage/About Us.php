<!--
Created By A V Chaitanya Prashanth , 700656889.
Olawunmi Shyllon , 700647413.
Vishnu Vardhan Reddy , 700654268 .
-->
<?php 
  
	//Variable to hold sessionId:
	$starter = session_id();
	
	//Start session if sessionId is empty:
	if(empty($starter)){
		session_start();
	$_SESSION['firstname'] = NULL;
    $_SESSION['lastname'] = NULL;	
	}
?> 
<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content = "width=device-width">
	<title>ISF.org</title>
	<link rel="stylesheet" type="text/css" href="Resources.css"/>
	
</head>

<body class="slider">
       <div class = "slides">
		<div class="logo"> <!-- how to link image to home.html-->
			<a href="Home.php"><img src="./Images/logo-main.png"></a>
			<nav>
				<ul>
					<li><a href="Home.php">Home</a></li>
					<li><a href="Resources.php">Resources</a></li>
					<li><a href="Resources.php">Services</a></li>
					<li><a href="Register.php">Register</a></li>
					<li><a href="Resources.php">About Us</a></li>
				</ul>
			</nav>
		</div>
		    <div style = "width : 890px; height : 20px; margin : 80px 0px 0px 60px;">
			<h1> -> You need to be a Registered member in ISF!!! <p style = "padding-left : 250px;">(OR)</p> 
			     -> You have to be Logged in ISF to view the Resources page !!!</h1></div>
			<div class = "homeform">
			<form class = "signinform" method = "post" action ="Resources.php">
			   <p><label style="font-size : 22px; margin-left : -20px;"> User Name </label> 
			   <input type = "text" name = "Username"placeholder = "username" style = "text-align : center; font : bold;" /></p>  
               <p><label style = "padding-right : 11px; font-size : 22px; margin-left : -20px;"> Password </label> 
			   <input type = "password" name = "Password"placeholder = "*********************" style = "text-align : center; font : bold;"/></p>  
               <p><input type = "submit" name = "Login"value = "LOGIN" style = "background-color:  #ff6600; font-weight: bold; margin-left : 65px; "/> 
			   <input type = "button" value = "NEW ACCOUNT" onclick = "window.location.href='Register.php'" style = "background-color:  #ff6600; font-weight: bold;"/></p>	
               <a href = "" style = "font-size : 20px; margin-left : -50px;"> <label>Forgot UserName ??</label> </a>	<br>		                 
			   <a href = "" style = "font-size : 20px; margin-left : -50px;"> <label>Forgot Password ??</label> </a>
            </form> 
            </div>			
                       <?php 
			       if(isset($_POST['Login'])){ // Login Button Validation
			            $username = $_POST['Username'];
				        $password = $_POST['Password'];
				            if(empty($username) || empty($password)) { //username and password validation
					           echo '<script>document.getElementById("error").innerHTML = "Either UserName or Password is blank ";</script>';
				             }elseif(isset($_POST['Login'])){
			        		           include("Loginphp.php");
									    if(loginCheck($username,$password)){
											echo '<script>window.location.href = "RealUser.php";</script>';}
										else{
											echo '<script>document.getElementById("error").innerHTML = "UserName doesnt exist please register again !!";</script>';}//end if(loginCheck)
				                    }else{
				                        header("Location : Resource.php");
									}//end if Login Validation
						  }// End If Login Validation
				  
               ?>
		<div id ="newsletter">
                    <form method ="" action ="">
                             <table style = "margin-left : 100px;">
							 <tr>
							 <td style = "padding : 0px 25px 0px 100px ;"> <p style = " color : #FFDEA8; font-size : 28px;"> Please Subscribe to our New's Letter  </p></td>
							 <td style = "padding : 5px 5px 0px 5px ;"><input type = "email" placeholder = "username@domain.com" style = "text-align : center ;"/></td>
							 <td style = "padding : 5px 5px 0px 5px ;"><input type = "text" placeholder = "Country Name"  list = "Country"  style = "text-align : center ;"/>
							 <datalist id="Country">
							 <option value = "Canada">
							 <option value = "India">
							 <option value = "Mexico">
							 <option value = "Australia">
							 <option value = "China">
							 <option value = "Indonesia">
							 <option value = "Malaysia">
							 <option value = "Italy">
							 <option value = "Cambodia">
							 <option value = "Austria">
							 </datalist></td>
							 <td style = "padding : 5px 5px 0px 5px ;"> 
							 <input type = "submit" value ="SUBMIT" style = "background-color :  #ff6600; font-weight: bold;"/></td>
							 </tr>
							 </table>
							
							 
					</form>
           </div>

	   </div>
    

   <footer>
           
             <table id = "footer-content">
			  <tr> <td> <img id = "footer-logo" src ="./Images/logo-footer.png" width = "80" height ="80" alt="ISP logo"></td>
			       <td id = "footer-text" style = "padding-left : 3%;">
			         <h6>About International Student page</h6>
			         <p>"..Our vision is to be the company that best recognizes and serves
       		             the needs of international students around the world.We strive to
			             provide students world-class resources to help them investigate and
			             pursue an international education, through relevant content, custom 
                         online tools and engaging websites that offer only best in class products and services."
			         </p>
				    </td>
				    <td id= "socialpic">
					      <p> <strong> To connect with us click on the below social media links</strong></p>
				          <p id="links" style = "padding-left : 225px">
						  <a href="https://www.facebook.com/" target ="New Window"> <img src="./Images./SocialMedia/Facebook.png" height="50" width="50" alt="Facebook" id="face"> </a>
						  <a href="https://plus.google.com/" target ="New Window"> <img src="./Images./SocialMedia/GooglePlus.png" height="50" width="50" alt="GooglePlus" id="google"> </a>
						  <a href="https://www.linkedin.com/uas/login" target ="New Window"> <img src="./Images./SocialMedia/Linkedin.png" height="50" width="50" alt="Linkedin" id="link"> </a>
						  <a href="https://twitter.com/" target ="New Window"> <img src="./Images./SocialMedia/twitter.png" height="50" width="50" alt="twitter" id="twit"> </a>
						  <a href="https://www.youtube.com/" target ="New Window"> <img src="./Images./SocialMedia/youtube.png" height="50" width="50" alt="youtube" id="tube"> </a>
						  </p>
					      
					</td> 
				</tr>
		     </table> 
		   
   </footer>
   
     
   
</body>
</html>