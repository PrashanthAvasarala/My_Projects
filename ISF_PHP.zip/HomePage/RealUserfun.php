
<!--Not able to insert table as done in the class for week 14 Inquiry cars-->
<?php

/*function dropdown(){ /* Using strcmp method here there in RegisterForm_Validation.php we are using in_array concept .
	 
	  $string1 = selectUniversity();
	    
			while($row = $string1->fetch_assoc()){ 
			/* Using string comparison method and excluding the in_array method to comapre 
			the values in datalist and university names in database */
				 /*if(strcmp($_POST['useruniversity'],$row['UniversityName'])){return $_POST['useruniversity'];}
			}
	  return false;
  
}*/
function resulttable($string1,$string2){
	$univname = $string1;
	$option = $string2;
	$sql = "SELECT FirstName,LastName ,University ,Status ,Email ,Mobile FROM students_table WHERE Status IN('".$option." ') AND University IN ('".$univname."') ;";
	$fetchclass = new DatabaseClass;
	
	  try{
		
	      $result= $fetchclass->dbquery($sql);
	          if(mysqli_num_rows($result)<=0){ 
			            echo "<p style = 'font-weight : bold; color : #562508; font-size: 25px; margin-left : 250px;'>  No International Graduate students are studing in this University !!</p>";
	                   }else{
	                         echo "<table style = 'background-color : lightgray ; margin-left : 250px;'>";
							 echo "<tr><td><td><td style = 'font-weight : bold; color : #562508; font-size: 25px'> FirstName</td></td></td>
							       <td><td><td style = 'font-weight : bold; color : #562508; font-size: 25px'> LastName</td></td></td>
								   <td><td><td style = 'font-weight : bold; color : #562508; font-size: 25px'> University</td></td></td>
								   <td><td><td style = 'font-weight : bold; color : #562508; font-size: 25px'> Status</td></td></td>
								   <td><td><td style = 'font-weight : bold; color : #562508; font-size: 25px'> Email</td></td></td>
								   <td><td><td style = 'font-weight : bold; color : #562508; font-size: 25px's> Mobile</td></td></td></tr>" ;
	                         while($row = $result->fetch_assoc()){
				             echo "<tr style = 'nth-child(odd) background-color : white;'>";
		                     echo "<td><td><td style = 'padding : 5px;'>".$row['FirstName']."</td></td></td>";
							 echo "<td><td><td style = 'padding : 5px;'>".$row['LastName']."</td></td></td>";
							 echo "<td><td><td style = 'padding : 5px;'>".$row['University']."</td></td></td>";
							 echo "<td><td><td style = 'padding : 5px;'>".$row['Status']."</td></td></td>";
							 echo "<td><td><td style = 'padding : 5px;'>".$row['Email']."</td></td></td>";
							 echo "<td><td><td style = 'padding : 5px;'>".$row['Mobile']."</td></td></td>";
					         echo "</tr>"; }
	                          }
	  }catch(Exception $e){ /* To catch error in connection failure or in query failure ; */
		      echo "<script>window.alert(".$e.getMessage().");</script>";
	      }
	                        echo "</table>";
}
?>
