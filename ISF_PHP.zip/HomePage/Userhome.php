<!--
Created by : 
Name : A V Chaitanya Prashanth  & Id : 700656889

-->
<?php 
  
	session_start();
	
	
?> 
<!DOCTYPE html>

<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content = "width=device-width">
	<title>ISF.org</title>
	<link rel="stylesheet" type="text/css" href="Usermain.css"/>
	<script type = "text/javascript" src = "userHomePage.js"></script>
	
</head>

<body>
   
       <div class="userhomeslides" style = "height : 95%;">
		<div class="userhomelogo"> 
			<a href="Userhome.php"><img src="./Images/logo-main.png"></a>
			<nav>
				<ul>
					<li><a href="Userhome.php">Home</a></li>
					<li><a href="RealUser.php">Resources</a></li>
					<li><a href="RealuserServices.php">Services</a></li>
					<li><a href="RealuserAboutUs.php">About Us</a></li>
					<li><a href="Userlogout.php">Log Out</a></li>
				</ul>
			    </nav>
			</div>
		    
</div>

   <footer> <!-- Footer tag opening -->
           
             <table id = "footer-content">
			  <tr> <td> <img id = "footer-logo" src ="./Images/logo-footer.png" width = "80" height ="80" alt="ISP logo"></td>
			       <td id = "footer-text" style = "padding-left : 3%;">
			         <h6>About International Student page</h6>
			         <p>"..Our vision is to be the company that best recognizes and serves
       		             the needs of international students around the world.We strive to
			             provide students world-class resources to help them investigate and
			             pursue an international education, through relevant content, custom 
                         online tools and engaging websites that offer only best in class products and services."
			         </p>
				    </td>
				    <td id= "socialpic">
					      <p> <strong> To connect with us click on the below social media links</strong></p>
				          <p id="links" style = "padding-left : 225px">
						  <a href="https://www.facebook.com/" target ="New Window"> <img src="./Images./SocialMedia/Facebook.png" height="50" width="50" alt="Facebook" id="face"> </a>
						  <a href="https://plus.google.com/" target ="New Window"> <img src="./Images./SocialMedia/GooglePlus.png" height="50" width="50" alt="GooglePlus" id="google"> </a>
						  <a href="https://www.linkedin.com/uas/login" target ="New Window"> <img src="./Images./SocialMedia/Linkedin.png" height="50" width="50" alt="Linkedin" id="link"> </a>
						  <a href="https://twitter.com/" target ="New Window"> <img src="./Images./SocialMedia/twitter.png" height="50" width="50" alt="twitter" id="twit"> </a>
						  <a href="https://www.youtube.com/" target ="New Window"> <img src="./Images./SocialMedia/youtube.png" height="50" width="50" alt="youtube" id="tube"> </a>
						  </p>
					      
					</td> 
				</tr>
		     </table> 
		   
   </footer>
   
     
   
</body>
</html>