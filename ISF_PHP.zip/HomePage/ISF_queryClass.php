<?php
class DatabaseClass {
protected static $connection;
public function connect(){
	//self::$connection variable should always be static
	
	if(!isset(self::$connection)){
		include("Dbconn.php");
		self::$connection = new mysqli($servername, $username, $password, $dbname);
	}
	if(self:: $connection === false) {
		return false;
	}
	return self::$connection;
}

public function dbquery($sql){
	$connection = $this->connect();
	 if($connection === false){
		 ("connection failed:" . $connection->connect_error);
		return  $connection->errno . PHP_EOL;
		die("DBMS Connection failed - error:".$connection->error . PHP_EOL);
	
	 }
	  $result = $connection->query($sql);
	 if($result){
		 return $result;
	 } else { 
	 return $connection->error;
	 }
	
}

}
?>