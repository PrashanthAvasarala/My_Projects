<!--
Created By 
A V Chaitanya Prashanth , 700656889.

-->
<?php session_start();?>


<html>

<head>
	<meta charset="utf-8">
	<meta name="viewport" content = "width=device-width">
	<title>ISF.org</title>
	<link rel="stylesheet" type="text/css" href="RealUser.css"/>
	<?php include("Insert_StudentDetails.php");?>
</head>

<body>
       <div class="userlogo"> 
			<a href="Home.php" ><img src="./Images/logo-main.png" style = "margin-top : 15px;"></a>
			<nav>
				<ul>
					<li><a href="Userhome.php">Home</a></li>
					<li><a href="RealUser.php">Resources</a></li>
					<li><a href="RealuserServices.php">Services</a></li>
					<li><a href="RealuserAboutUs.php">About Us</a></li>
					<li><a href="Userlogout.php">Log Out</a></li>
					
				</ul>
			</nav>
		</div>
		 <div style = "margin-top : 10px; background-color :#b5b9ce ;">  
          <?php
		  
		  echo '<p style = "text-shadow: 1px 1px 2px black, 0 0 25px blue, 0 0 5px darkblue;letter-spacing : 1px;font-size : 30px; font-weight: Normal ; margin-left : 400px;"> Welcome Back'. '   '.$_SESSION['lastname'].'     '.$_SESSION['firstname'].'  !!!</p>';
		  ?>			
          </div>
		   
	   
        <div style = "margin-top : -125px; background-color : #b5b9ce ;">
		<form  method="POST" action="RealUser.php" style = "margin-left : 350px;margin-top : 50px;">
			<p><label style = "margin-left : 100px; font-weight : bold;"> Select University: </label> <input type="text" name="useruniversity" placeholder = "Admitted University" list= "Useruniversity" style = "margin-left : 20px;"/>
			<!-- Please Include the PHP file of the below function which we are going to use or else datalist will not work and below buttons , footer will not appear it is an error  -->
			<datalist id= "Useruniversity"> 
			<?php 
			$result = selectUniversity(); // include corresponding PHP file
			while($row = $result->fetch_assoc()){
				$UserUniversity = $row['UniversityName'];
				echo "<option value = '".$UserUniversity."'</option>";
			}
			 ?> 
			</datalist></p>
			<table><tr>
			<td> <input type="submit" name="current" value="To See Current Students " style = "background-color:  #ff6600; font-weight: bold;"/></td>
			<td><input type="submit" name="alumni" value="To See Alumni Students"  style = "background-color:  #ff6600; font-weight: bold;"/></td>
			<td><input type="submit" name="enrolled" value="To See Enrolled Students"  style = "background-color:  #ff6600; font-weight: bold;"/></td>
			</tr></table>
		 </form>
		 </div>
		 
	       <?php
		         include("RealUserfun.php");
			if(empty($_POST['useruniversity']) && (isset($_POST['current']) ||isset($_POST['alumni'])|| isset($_POST['enrolled']))){
				       echo "<p style = 'font-weight : bold; color : #562508; font-size: 25px; margin-left : 250px;'> You did not select any University !! Please select one university ..</p>";
			   }else{
				     header("Location : RealUser.php"); 
					 }
						                  
			
			   if(!empty($_POST['useruniversity'])){ /* In Datalist User can select or write the university name if student writes other university names not in the list it should not accept , that is the reason we use dropdown function to compare university ,but we are not comparing / not validating here */
	              if(isset($_POST['current'])){
					    resulttable($_POST['useruniversity'],'Current Student'); /*We can call dropdown function in RealUserfun.php to compare the value in the university text box and in the database and if it returns false we need to write an else block to say we dont provide information about that written university in our database .*/
					  }elseif(isset($_POST['alumni'])){
						   resulttable($_POST['useruniversity'],'Alumni');
					         }elseif(isset($_POST['enrolled'])){
								  resulttable($_POST['useruniversity'],'Enrolled');
							    }else{
								header("Location : RealUser.php"); }
				}
	        ?>
			<p></p><p></p>
        <input type = "button" value = "Reset" onclick = "window.location.href='RealUser.php'" style = "background-color:  #ff6600; font-weight: bold; margin-left : 580px;"\>
	 
   <div style = "height : 160px; margin-top : 160px;">
           
             <table id = "userfooter" style = "padding-top : 15px;">
			  <tr> <td> <img id = "footer-logo" src ="./Images/logo-footer.png" width = "80" height ="80" alt="ISP logo"></td>
			       <td id = "userfootertext" style = "padding-left : 3%;">
			         <h6>About International Student page</h6>
			         <p>"..Our vision is to be the company that best recognizes and serves
       		             the needs of international students around the world.We strive to
			             provide students world-class resources to help them investigate and
			             pursue an international education, through relevant content, custom 
                         online tools and engaging websites that offer only best in class products and services."
			         </p>
				    </td>
				    <td id= "usersocialpic">
					      <p> <strong> To connect with us click on the below social media links</strong></p>
				          <p id="links" style = "padding-left : 225px">
						  <a href="https://www.facebook.com/" target ="New Window"> <img src="./Images./SocialMedia/Facebook.png" height="50" width="50" alt="Facebook" id="userface"> </a>
						  <a href="https://plus.google.com/" target ="New Window"> <img src="./Images./SocialMedia/GooglePlus.png" height="50" width="50" alt="GooglePlus" id="usergoogle"> </a>
						  <a href="https://www.linkedin.com/uas/login" target ="New Window"> <img src="./Images./SocialMedia/Linkedin.png" height="50" width="50" alt="Linkedin" id="userlink"> </a>
						  <a href="https://twitter.com/" target ="New Window"> <img src="./Images./SocialMedia/twitter.png" height="50" width="50" alt="twitter" id="usertwit"> </a>
						  <a href="https://www.youtube.com/" target ="New Window"> <img src="./Images./SocialMedia/youtube.png" height="50" width="50" alt="youtube" id="usertube"> </a>
						  </p>
					      
					</td> 
				</tr>
		     </table> 
		   
   </div>

   
</body>
</html>
