//Created By A v Chaitanya Prashanth , 700656889.

window.addEventListener("load",start,false);

function start(){ // Initiazling the function
	swapImage();
}

var counter =0;


 
function swapImage() // For rotating images
{
	var imgs = ["./Images./Slides/slide1.jpg","./Images./Slides/slide2.jpg", "./Images./Slides/slide3.jpg",
	"./Images./Slides/slide4.jpg","./Images./Slides/slide5.jpg", "./Images./Slides/slide6.jpg", "./Images./Slides/slide7.jpg"];
	 
     if (counter >=imgs.length) {counter = 0}
     document.getElementsByClassName("userhomeslides")[0].style.backgroundImage = 'url(" '+imgs[counter]+' ")';
	 counter++;
     setTimeout(swapImage,2000);
  
 } // end of the function
 

