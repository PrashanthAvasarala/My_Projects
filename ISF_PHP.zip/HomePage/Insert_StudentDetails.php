<?php


    
include("ISF_queryClass.php");	
function insertStudentDetail(){	
   $firstName = $_POST['firstName'];
   $lastName = $_POST['lastName'];
   $university = $_POST['University'];
   $status = $_POST['Status'];
   $userName = $_POST['userName'];
   $password = $_POST['password'];
   $email = $_POST['email'];
   $mobile = $_POST['mobile'];
   $country = $_POST['Country'];
   
   
     $dbclass = new DatabaseClass;
	 $sql = "INSERT INTO students_table(FirstName , LastName , University , Status , UserName , Password , Email , Mobile , OriginCountry)
           VALUES('$firstName' , '$lastName' , '$university' , '$status' , '$userName' , '$password' , '$email' , '$mobile' ,'$country' );";
		   try{
			    $result = $dbclass->dbquery($sql);
				if($result){
			     //send the sql insert query
			     /*echo "<p style = 'margin-left : 100px ; color : #cc0066 ; font-weight : bold ; font-size : 26px;'> You have been succesfully registered to International Student Website !! </p> ";*/
			     echo '<script> document.getElementById("text").innerHTML = "You have been succesfully registered to ISF Website !!"; </script>';
			     }else{    //die
			            throw new Exception("Insert Failed " . $result->error);
		               }
		      }catch(Exception $e){
			   die("error:" . $e->getMessage());
		       }
    
	
}	


function selectUniversity(){
	     $dbclass = new DatabaseClass;
	     $sql = "SELECT UniversityName FROM university_table ;" ;
		 try{
			 $result = $dbclass->dbquery($sql);
			 if($result){
				 return $result;
			 }
		 }catch(Exception $e){
			 echo "<script>window.alert(".$e.getMessage().")</script>";
		 }
}
 
function selectEmail(){
	     $dbclass = new DatabaseClass;
	     $sql = "SELECT Email FROM students_table;" ;
		 try{
			 $result = $dbclass->dbquery($sql);
			 if($result){
				 return $result;
			 }
		 }catch(Exception $e){
			 echo "<script>window.alert(".$e.getMessage().")</script>";
		 }
} 
   


?>