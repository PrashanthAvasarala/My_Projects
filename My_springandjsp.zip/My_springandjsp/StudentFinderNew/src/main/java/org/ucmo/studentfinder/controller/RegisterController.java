package org.ucmo.studentfinder.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;
import org.ucmo.studentfinder.dao.DBConnection;
import org.ucmo.studentfinder.model.LoginForm;
import org.ucmo.studentfinder.model.Student;

@Controller
public class RegisterController {
	
	
	
	@RequestMapping(method=RequestMethod.POST, value="/submitRegistration" )
	public ModelAndView submitRegistration(HttpServletResponse response,  HttpServletRequest request ) throws IOException{
		
		ModelAndView modelAndView = null;
		Student s = new Student();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String studentName = request.getParameter("studentName");

		String studentID = request.getParameter("studentID");
		long id = Long.parseLong(studentID);

		String universityName = request.getParameter("universityID");
		// int universityname=

		String fieldOfMajor = request.getParameter("fieldOfMajor");

		String contact = request.getParameter("contact");
		long contactnum = Long.parseLong(contact);

		String studentLocation = request.getParameter("studentLocation");
		String email = request.getParameter("email");

		String password = request.getParameter("password");

		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?)");

			ps.setString(1, studentName);
			ps.setLong(2, id);
			ps.setString(3, universityName);
			ps.setString(4, fieldOfMajor);
			ps.setLong(5, contactnum);
			ps.setString(6, studentLocation);
			ps.setString(7, email);
			ps.setString(8, password);

			if(ps.executeUpdate()>0){
				modelAndView = new ModelAndView("registersuccess"); 
			}
		} catch (Exception se) {
			se.printStackTrace();
		}

		return modelAndView;
		
	}
}
