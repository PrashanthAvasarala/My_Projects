package org.ucmo.studentfinder.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.ucmo.studentfinder.dao.DBConnection;
import org.ucmo.studentfinder.dao.StudentName;
import org.ucmo.studentfinder.dao.UniversityList;
import org.ucmo.studentfinder.model.Student;

@Controller
public class UpdateDeleteController {

	@RequestMapping(method = RequestMethod.POST, value = "/updatedeletestudentinfo")
	public ModelAndView updatedeletestudentinfo(@RequestParam("action") String action, @RequestParam("stdid") String stdid,
			@RequestParam("stdname") String stdname, @RequestParam("stdcontact") String stdcontact) throws IOException {
		if (action.equalsIgnoreCase("update")) {

			try {

				long contactnum = Long.parseLong(stdcontact);
				long studentid=	Long.parseLong(stdid);

				// creating connection with the database
				DBConnection db = new DBConnection();
				Connection con = db.getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE STUDENT SET studentName=? WHERE studentID=?");

				ps.setString(1, stdname);
				ps.setLong(2, studentid);

				if (ps.executeUpdate() >= 0) {

				}
			} catch (Exception se) {
				se.printStackTrace();
			}
		} else {

			try {
				long studentid=Long.parseLong(stdid);
				// creating connection with the database
				DBConnection db = new DBConnection();
				Connection con = db.getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM STUDENT WHERE studentID=?");
				ps.setLong(1, studentid);
				if (ps.executeUpdate() >= 0) {

				}
			} catch (Exception se) {
				se.printStackTrace();
			}
		}

		return null;
	}
}
