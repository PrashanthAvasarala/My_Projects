package org.ucmo.studentfinder.dao;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;



public class DBConnection {
	
	Connection con = null;
	PreparedStatement st = null;;
	ResultSet rs = null;
	
	public Connection getConnection() throws SQLException{
		
		try {
		    Class.forName("com.mysql.jdbc.Driver");
		} 
		catch (ClassNotFoundException e) {
		    // TODO Auto-generated catch block
		    e.printStackTrace();
		} 
		try {
			String url="jdbc:mysql://localhost:3306/internationalstudentfinder"; 
			String user="root";
			String password="";
			con= DriverManager.getConnection(url, user, password);
			//System.out.println("Successful Connection");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
		
	}
	
	

	private void closeConnection() {
		
		// close all open database objects
				try
				{
					if (rs != null){
						rs.close();
						rs = null;
					}
					if (st != null){
						st.close();
						st = null;
					}
					if (con != null){
						con.close();
						con = null;
					}
				}catch(Exception e){
					e.printStackTrace();
				}
		
	}
	
	

}

