package org.ucmo.studentfinder.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.ucmo.studentfinder.dao.DBConnection;
import org.ucmo.studentfinder.dao.GetLoginDetails;
import org.ucmo.studentfinder.dao.UniversityList;
import org.ucmo.studentfinder.model.LoginForm;
import org.ucmo.studentfinder.model.Student;

@Controller
public class LoginController {

	@RequestMapping(method = RequestMethod.POST, value = "/submitLogin")
	public String submitLogin(@Valid @ModelAttribute("loginform") LoginForm loginform,  BindingResult result,Model model) throws IOException {

		ModelAndView modelAndView = new ModelAndView("userprofile");
		 if (result.hasErrors()) {
			return "Login";
			
	        }
		GetLoginDetails login = new GetLoginDetails();

		String pwd = login.getStudentpasswordById(loginform.getUsername());
		
		
		if ((!(loginform.getPassword() == null) && pwd.equalsIgnoreCase(loginform.getPassword()))) {
			model.addAttribute("username",loginform.getUsername());
			return "userprofile";
		}
		else{
			return "Login";  
		}
	}
	
	@RequestMapping(value="/userprofile",method=RequestMethod.GET )
	public ModelAndView userprofile(@RequestParam("username") String username) throws IOException{
		ModelAndView modelAndView = new ModelAndView("userprofile");
		return modelAndView;
	}
	
	
	
	
	@RequestMapping(value="/updateprofile",method=RequestMethod.GET )
	public ModelAndView updateprofile(@RequestParam("username") String username) throws IOException{
		ModelAndView modelAndView = new ModelAndView("updateprofile");
		Student s= new Student();
		UniversityList u= new UniversityList();
		String universityname= null;
		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from student where studentName=?");
			
			ps.setString(1,username);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()){
				
				s.setStudentName(rs.getString("studentName"));
				s.setStudentID(rs.getLong("studentID"));
				s.setFieldOfMajor(rs.getString("fieldOfMajor"));
				//s.setUniversityName((rs.getInt("universityName")));
				s.setStudentLocation(rs.getString("studentLocation"));
				s.setContact(rs.getLong("contact"));
				universityname = u.getUniversityNameusingID(rs.getInt("universityID"));
			}
		} catch (Exception se) {
			se.printStackTrace();
		}
		modelAndView.addObject("studentinfo",s);
		modelAndView.addObject("universityname", universityname);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/submitupdateprofile",method=RequestMethod.POST )
	public ModelAndView submitupdateprofile(HttpServletResponse response,  HttpServletRequest request ) throws IOException{
		
	
		Student s = new Student();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String studentName = request.getParameter("stdname");

		String studentID = request.getParameter("studentID");
		long id = Long.parseLong(studentID);

		String universityName = request.getParameter("universityID");
		// int universityname=

		String fieldOfMajor = request.getParameter("fieldOfMajor");

		String contact = request.getParameter("contact");
		long contactnum = Long.parseLong(contact);

	

		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE STUDENT SET studentName=?,universityID=?,fieldOfMajor=?,contact=? WHERE studentID=?");

			ps.setString(1, studentName);
			ps.setString(2, universityName);
			ps.setString(3, fieldOfMajor);
			ps.setLong(4, contactnum);
			ps.setLong(5, id);
			if (ps.executeUpdate() >= 0) {
				

			}
		} catch (Exception se) {
			se.printStackTrace();
		}
		
		return null;
	}

	
	
	@RequestMapping(value="/deleteprofile",method=RequestMethod.GET )
	public ModelAndView deleteprofile(@RequestParam("username") String username) throws IOException{
		ModelAndView modelAndView = new ModelAndView("deleteprofile");
		Student s= new Student();
		UniversityList u= new UniversityList();
		String universityname= null;
		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("select * from student where studentName=?");
			
			ps.setString(1,username);
			ResultSet rs= ps.executeQuery();
			
			while(rs.next()){
				
				s.setStudentName(rs.getString("studentName"));
				s.setStudentID(rs.getLong("studentID"));
				s.setFieldOfMajor(rs.getString("fieldOfMajor"));
				//s.setUniversityName((rs.getInt("universityName")));
				s.setStudentLocation(rs.getString("studentLocation"));
				s.setContact(rs.getLong("contact"));
				universityname = u.getUniversityNameusingID(rs.getInt("universityID"));
			}
		} catch (Exception se) {
			se.printStackTrace();
		}
		modelAndView.addObject("studentinfo",s);
		modelAndView.addObject("universityname", universityname);
		
		return modelAndView;
	}
	
	@RequestMapping(value="/submitdeleteprofile",method=RequestMethod.POST )
	public ModelAndView submitdeleteprofile(HttpServletResponse response,  HttpServletRequest request ) throws IOException{

		Student s = new Student();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String studentName = request.getParameter("stdname");

		String studentID = request.getParameter("studentID");
		long id = Long.parseLong(studentID);

		String universityName = request.getParameter("universityID");
		// int universityname=

		String fieldOfMajor = request.getParameter("fieldOfMajor");

		String contact = request.getParameter("contact");
		long contactnum = Long.parseLong(contact);

	

		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("DELETE FROM STUDENT where studentID=?");

			
			ps.setLong(1, id);
			if (ps.executeUpdate() >= 0) {
				

			}
		} catch (Exception se) {
			se.printStackTrace();
		}
		
		return null;
	}
	
}
