package org.ucmo.studentfinder.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.ucmo.studentfinder.dao.StudentName;
import org.ucmo.studentfinder.dao.UniversityList;
import org.ucmo.studentfinder.model.Student;

@Controller
public class StudentInfoController {
	
	@RequestMapping(method=RequestMethod.GET,value = "/HomePage")
	public ModelAndView homePage(HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		//Need to implement home page logic
		
		
		UniversityList universitynamelist=new UniversityList();
		//list of university names
		//List<University> universitynamelist= univlist.getUniversity();
		
		 
		ModelAndView modelAndView = new ModelAndView("Resources");
		modelAndView.addObject("universitynamelist", universitynamelist.getUniversityNames());
 
		return modelAndView;
	}
	

	@RequestMapping(method=RequestMethod.GET,value = "/Resources")
	public ModelAndView ViewUniversities(HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		UniversityList universitynamelist=new UniversityList();
		//list of university names
		//List<University> universitynamelist= univlist.getUniversity();
		
		 
		ModelAndView modelAndView = new ModelAndView("Resources");
		modelAndView.addObject("universitynamelist", universitynamelist.getUniversityNames());
 
		return modelAndView;
	}
	
	@RequestMapping(method = RequestMethod.GET, value = "/viewUniversityInfo")
	public ModelAndView viewUniversityInfo(
			@RequestParam("universitynames") String universityName) throws IOException {
		UniversityList univlist=new UniversityList();
		int universityID = univlist.getUniversityIDusingName(universityName);
		ModelAndView mav= new ModelAndView("studentinfo");
		mav.addObject("universityID", universityID);
		System.out.println(universityID);

		StudentName s = new StudentName();
		List<Student> student=s.getName(universityID);
		UniversityList universitynamelist=new UniversityList();
		

		//list of university names
		//List<University> universitynamelist= univlist.getUniversity();
		
		 
		mav.addObject("universitynamelist", universitynamelist.getUniversityNames());
		
		mav.addObject("studentList", student);
		return mav;
	}
}
