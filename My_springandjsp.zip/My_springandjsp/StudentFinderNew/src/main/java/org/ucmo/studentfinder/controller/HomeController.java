package org.ucmo.studentfinder.controller;

import java.io.IOException;

import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.ucmo.studentfinder.model.AdminForm;
import org.ucmo.studentfinder.model.LoginForm;

@Controller
public class HomeController {

	@RequestMapping(value="/", method=RequestMethod.GET)
	public ModelAndView test(HttpServletResponse response) throws IOException{
		return new ModelAndView("HomePage");
	}
	
	@RequestMapping(value="/registration",method=RequestMethod.GET )
	public ModelAndView registration(HttpServletResponse response) throws IOException{
		return new ModelAndView("registration");
	}
	
	@RequestMapping(value="/Login",method=RequestMethod.GET )
	public ModelAndView Login(HttpServletResponse response) throws IOException{
		ModelAndView mav= new  ModelAndView("Login");
		mav.addObject("loginform", new LoginForm());
		return mav;
	}
	
	@RequestMapping(value="/admin",method=RequestMethod.GET )
	public ModelAndView adminLogin(HttpServletResponse response) throws IOException{
		ModelAndView mav= new  ModelAndView("admin");
		mav.addObject("adminForm", new AdminForm());
		return mav;
	}

}
