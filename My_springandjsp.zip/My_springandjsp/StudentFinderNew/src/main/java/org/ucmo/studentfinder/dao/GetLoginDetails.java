package org.ucmo.studentfinder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import org.ucmo.studentfinder.model.Student;

public class GetLoginDetails {
	
	DBConnection db = new DBConnection();
	Connection con;
	String password=null;
	
	public String getStudentpasswordById(String studentname){		
		try {
			
			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select password from student where studentName=?");
			pst.setString(1, studentname);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				
				Student s=new Student();
				
				s.setPassword(rs.getString("password"));
				password=s.getPassword();

			}

			rs.close();
			pst.close();
			con.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return password;
	}
	
	public String getAdminPassword(String userName){		
		try {
			
			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select password from admin where userName=?");
			pst.setString(1, userName);
			ResultSet rs = pst.executeQuery();
			
			while(rs.next()) {
				
				Student s=new Student();
				
				s.setPassword(rs.getString("password"));
				password=s.getPassword();

			}

			rs.close();
			pst.close();
			con.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return password;
	}
	


}
