package org.ucmo.studentfinder.controller;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Random;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.ucmo.studentfinder.dao.DBConnection;
import org.ucmo.studentfinder.dao.GetLoginDetails;
import org.ucmo.studentfinder.dao.UniversityList;
import org.ucmo.studentfinder.model.AdminForm;

@Controller
public class AdminController {

	@RequestMapping(method = RequestMethod.POST, value = "/submitAdminLogin")
	public ModelAndView submitAdminLogin(@Valid @ModelAttribute("adminForm") AdminForm adminForm, Model model)
			throws IOException {

		ModelAndView modelAndView;
		GetLoginDetails login = new GetLoginDetails();
		String pwd = ("admin".equalsIgnoreCase(adminForm.getUsername())) ? login.getAdminPassword(adminForm.getUsername()) : null;

		if ((!(adminForm.getPassword() == null) && pwd != null && pwd.equalsIgnoreCase(adminForm.getPassword()))) {
			modelAndView = new ModelAndView("adminProfile");
			model.addAttribute("username", adminForm.getUsername());
		} else {
			modelAndView = new ModelAndView("errorAdmin");
		}

		return modelAndView;
	}

	@RequestMapping(method = RequestMethod.GET, value = "/Home")
	public ModelAndView Home(HttpServletRequest request, HttpServletResponse response) throws IOException {

		return new ModelAndView("HomePage");
	}
	
	@RequestMapping(value="/addUniversity",method=RequestMethod.GET )
	public ModelAndView addUniversity(HttpServletResponse response) throws IOException{
		return new ModelAndView("addUniversity");
	}

	@RequestMapping(method = RequestMethod.POST, value = "/submitUniversity")
	public ModelAndView submitUniversity(HttpServletResponse response, HttpServletRequest request, Model model)
			throws IOException {

		ModelAndView modelAndView = null;

		Random random = new Random();
		int posRandom = random.nextInt(100) + 1;

		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into university values(?,?, ?)");

			ps.setInt(1, posRandom);
			ps.setString(2, request.getParameter("universityName"));
			ps.setString(3, request.getParameter("location"));
			int result = ps.executeUpdate();
			if (result > 0) {
				modelAndView = new ModelAndView("successUniversity");
			}
		} catch (Exception se) {
			modelAndView = new ModelAndView("errorUniversity");
			se.printStackTrace();
		}

		return modelAndView;
	}
	
	@RequestMapping(value="/deleteUniversity",method=RequestMethod.GET )
	public ModelAndView deleteUniversity(HttpServletResponse response, Model model) throws IOException{
		UniversityList univList = new UniversityList();
		model.addAttribute("universityList", univList.getUniversity());
		return new ModelAndView("deleteUniversity");
	}
    
	@RequestMapping(method = RequestMethod.POST, value = "/submitDeleteUniversity")
	public ModelAndView submitDeleteUniv(HttpServletResponse response, HttpServletRequest request, Model model)
			throws IOException {

		ModelAndView modelAndView = null;
		
		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("delete from university where universityId = ?");
            System.out.println(request.getParameter("univId"));
			ps.setInt(1,Integer.parseInt(request.getParameter("univId")));

			int result = ps.executeUpdate();
			if (result > 0) {
				modelAndView = new ModelAndView("deleteUnivConf");
			}
		} catch (Exception ex) {
			modelAndView = new ModelAndView("errorUniversity");
			ex.printStackTrace();
		}
		return modelAndView;
	}

}
