package org.ucmo.studentfinder.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import org.ucmo.studentfinder.model.*;

public class UniversityList {

	DBConnection db = new DBConnection();
	Connection con;
	List<University> universityList = new ArrayList<University>();

	public List<University> getUniversityNames() {
		try {

			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select distinct universityName from university");
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				University u = new University();
				u.setUniversityName(rs.getString("universityName"));
				universityList.add(u);

			}

			rs.close();
			pst.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return universityList;
	}

	public List<University> getUniversity() {
		try {

			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select * from university");
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				University u = new University();
				u.setUniversityID(rs.getInt("universityID"));
				u.setUniversityName(rs.getString("universityName"));
				u.setUniversityLocation(rs.getString("location"));
				universityList.add(u);

			}

			rs.close();
			pst.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return universityList;
	}

	public int getUniversityIDusingName(String universityname) {

		int univID = 0;
		try {

			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select universityID from university where universityName=?");
			pst.setString(1, universityname);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				University u = new University();

				u.setUniversityID(rs.getInt("universityID"));
				univID = u.getUniversityID();
			}

			rs.close();
			pst.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return univID;

	}
	
	public String getUniversityNameusingID(int universityid) {

		String univname = null;
		try {

			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select universityName from university where universityID=?");
			pst.setInt(1, universityid);

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				University u = new University();

				u.setUniversityName(rs.getString("universityName"));
				univname = u.getUniversityName();
			}

			rs.close();
			pst.close();
			con.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return univname;

	}


}
