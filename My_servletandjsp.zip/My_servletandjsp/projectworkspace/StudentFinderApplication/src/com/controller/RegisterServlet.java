package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DBConnection;
import com.model.Student;

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public RegisterServlet() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		Student s = new Student();

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String studentName = request.getParameter("studentName");

		String studentID = request.getParameter("studentID");
		long id = Long.parseLong(studentID);

		String universityName = request.getParameter("universityID");
		// int universityname=

		String fieldOfMajor = request.getParameter("fieldOfMajor");

		String contact = request.getParameter("contact");
		long contactnum = Long.parseLong(contact);

		String studentLocation = request.getParameter("studentLocation");
		String email = request.getParameter("email");

		String password = request.getParameter("password");

		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?,?,?,?)");

			ps.setString(1, studentName);
			ps.setLong(2, id);
			ps.setString(3, universityName);
			ps.setString(4, fieldOfMajor);
			ps.setLong(5, contactnum);
			ps.setString(6, studentLocation);
			ps.setString(7, email);
			ps.setString(8, password);

			if (ps.executeUpdate() >= 0) {

				RequestDispatcher dispatch = getServletContext().getRequestDispatcher("/updateprofile.jsp");
				dispatch.forward(request, response);

			}
		} catch (Exception se) {
			se.printStackTrace();
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("in dopost");
		doGet(request, response);
	}

}
