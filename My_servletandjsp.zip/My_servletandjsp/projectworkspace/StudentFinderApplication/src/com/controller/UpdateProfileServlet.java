package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DBConnection;

/**
 * Servlet implementation class UpdateProfileServlet
 */
@WebServlet("/UpdateProfile")
public class UpdateProfileServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public UpdateProfileServlet() {
        super();
       
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		String studentName = request.getParameter("stdname");
		String studentID = request.getParameter("stdId");
		long id = Long.parseLong(studentID);
		
		//int id = Integer.parseInt(studentID);
		
		String universityName = request.getParameter("universtyname");
		
		String fieldOfMajor = request.getParameter("major");
		String contact = request.getParameter("contact");
		long contactnum = Long.parseLong(contact);
		
		String studentLocation = request.getParameter("location");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		try {

			// creating connection with the database
			DBConnection db = new DBConnection();
			Connection con = db.getConnection();
			PreparedStatement ps = con.prepareStatement("UPDATE STUDENT SET studentName=? WHERE studentID=?");

			ps.setString(1, studentName);
			ps.setLong(2, id);
			
			if (ps.executeUpdate() >= 0) {
				out.println("profile updated");
			}
		}catch (Exception se) {
				se.printStackTrace();
			}
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("updateprofile servlet");
		doGet(request, response);
	}

}
