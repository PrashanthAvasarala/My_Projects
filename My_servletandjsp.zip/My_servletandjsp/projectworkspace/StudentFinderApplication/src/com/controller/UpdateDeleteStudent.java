package com.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DBConnection;

@WebServlet("/UpdateDeleteStudent")
public class UpdateDeleteStudent extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public UpdateDeleteStudent() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		
		if ((request.getParameter("action")).equalsIgnoreCase("update")) {

			try {
				
				String studentID = request.getParameter("stdid");
				String studentName = request.getParameter("stdname");
				long id = Long.parseLong(studentID);
				String contact = request.getParameter("stdcontact");
				long contactnum = Long.parseLong(contact);
				

				// creating connection with the database
				DBConnection db = new DBConnection();
				Connection con = db.getConnection();
				PreparedStatement ps = con.prepareStatement("UPDATE STUDENT SET studentName=? WHERE studentID=?");

				ps.setString(1, studentName);
				ps.setLong(2, id);

				if (ps.executeUpdate() >= 0) {
					out.println("updated");

				}
			} catch (Exception se) {
				se.printStackTrace();
			}
		}
		
		else{
			
			try {

				// creating connection with the database
				DBConnection db = new DBConnection();
				Connection con = db.getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE FROM STUDENT WHERE studentID=?");
				System.out.println(Long.parseLong(request.getParameter("stdid")));
				ps.setLong(1,Long.parseLong(request.getParameter("stdid")));
				if (ps.executeUpdate() >= 0) {
					out.println("deleted");

				}
			} catch (Exception se) {
				se.printStackTrace();
			}
		}
					
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
		System.out.println("in dopost updatequery");
	}

}
