package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.model.Student;

public class StudentName {
	DBConnection db = new DBConnection();
	Connection con;
	List<Student> studentsList = new ArrayList<Student>();
	
	public List<Student> getName(int univid){		
		try {
			System.out.println("in method");
			con = db.getConnection();
			PreparedStatement pst = con.prepareStatement("select studentID,studentName,contact from student where universityID=?");
			pst.setInt(1, univid);
			ResultSet rs = pst.executeQuery();

			while(rs.next()) {
				
				Student s=new Student();
				s.setStudentID(rs.getLong("studentID"));
				s.setStudentName(rs.getString("studentName"));
				s.setContact(rs.getLong("contact"));
				studentsList.add(s);

			}

			rs.close();
			pst.close();
			con.close();
		}catch(Exception e){
			e.printStackTrace();
		}
		return studentsList;
	}
	

}
