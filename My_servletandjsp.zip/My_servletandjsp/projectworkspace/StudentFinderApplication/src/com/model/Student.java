package com.model;

public class Student {
	
	private String studentName;
	private long studentID;
	private int universityID;
	
	private String universityName;
	private String fieldOfMajor;
	private long contact;
	private String studentLocation;
	private String email;
	private String password;
	
	public int getUniversityID() {
		return universityID;
	}
	public void setUniversityID(int universityID) {
		this.universityID = universityID;
	}
	
	
	public String getStudentName() {
		return studentName;
	}
	public void setStudentName(String studentName) {
		this.studentName = studentName;
	}
	public long getStudentID() {
		return studentID;
	}
	public void setStudentID(long studentID) {
		this.studentID = studentID;
	}
	public String getUniversityName() {
		return universityName;
	}
	public void setUniversityName(String universityName) {
		this.universityName = universityName;
	}
	public String getFieldOfMajor() {
		return fieldOfMajor;
	}
	public void setFieldOfMajor(String fieldOfMajor) {
		this.fieldOfMajor = fieldOfMajor;
	}
	public long getContact() {
		return contact;
	}
	public void setContact(long contact) {
		this.contact = contact;
	}
	public String getStudentLocation() {
		return studentLocation;
	}
	public void setStudentLocation(String studentLocation) {
		this.studentLocation = studentLocation;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
}
